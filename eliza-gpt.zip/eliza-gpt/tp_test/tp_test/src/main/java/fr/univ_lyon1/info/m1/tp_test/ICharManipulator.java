package fr.univ_lyon1.info.m1.tp_test;

public interface ICharManipulator {
    String invertOrder(String s);
    String invertCase(String s);
    String removePattern(String s, String x);
}
